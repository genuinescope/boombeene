  <div class="container pagination-centered">
  	<hr />
	<p>Developed by degt - 2012</p>
	  
  </div>

  </body>
</html>